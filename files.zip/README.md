# SoftGrowTech_Invoice_Generator

## Overview
A console-based **Invoice Generator** built in Python as part of the SoftGrowTech
Internship (Task 1 – Python Programming, Project 3).

The program takes customer and item details as input, calculates tax and discount,
generates a formatted invoice, and saves it to a text file using file handling.

## Features
- Menu-driven interface (Generate Invoice / View Past Invoices / Exit)
- Add multiple items with quantity and price
- Automatic tax calculation (5%)
- Automatic discount for orders above a set threshold (10% off orders > 1000)
- Unique invoice number generated from date & time
- Saves each invoice as a separate `.txt` file inside the `invoices/` folder
- Maintains a running log (`invoice_log.txt`) of all generated invoices
- Input validation for names, quantities, and prices

## Tools Used
- Python 3
- File Handling (`open`, `write`, `read`)

## How to Run
1. Make sure Python 3 is installed.
2. Open the project folder in PyCharm (or any IDE) or a terminal.
3. Run the script:
   ```bash
   python invoice_generator.py
   ```
4. Follow the on-screen menu to generate and view invoices.

## Project Structure
```
SoftGrowTech_Invoice_Generator/
│── invoice_generator.py   # Main program
│── invoice_log.txt        # Auto-created log of all invoices
│── invoices/               # Auto-created folder storing individual invoices
│── README.md
```

## Example Output
```
=============================================
               INVOICE
=============================================
Invoice No : INV-20260724-145832
Date       : 24-07-2026 14:58:32
Customer   : John Doe
Phone      : 9876543210
---------------------------------------------
Item             Qty     Price       Subtotal
---------------------------------------------
Laptop             1   1200.00        1200.00
Mouse              2     25.00          50.00
---------------------------------------------
Subtotal                              1250.00
Tax (5%)                                62.50
Discount                              -125.00
---------------------------------------------
GRAND TOTAL                           1187.50
=============================================
         Thank you for your business!
=============================================
```

## Benefits
- Hands-on practice with Python fundamentals: functions, loops, conditionals
- Real-world application of file handling
- Understanding of business logic (billing, tax, discount calculations)

## Author
Internship Project – SoftGrowTech (#SoftGrowTech)
